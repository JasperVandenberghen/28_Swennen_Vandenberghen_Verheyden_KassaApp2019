package controller;

import model.Dobbelspel;
import view.EindeSpelAlert;

public class EindeSpelController {

    public static boolean notify(Dobbelspel dobbelspel){
        return EindeSpelAlert.show(dobbelspel.getWinnaarSpel().toString());
    }
}
