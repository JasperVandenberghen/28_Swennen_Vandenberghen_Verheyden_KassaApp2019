package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import model.Dobbelspel;
import model.Observer;
import model.Speler;
import view.PlayerView;

public class PlayerController implements Observer {
    private PlayerView view;
    private Dobbelspel model;
    private int spelerID;

    public PlayerController(PlayerView view,Dobbelspel model, int spelerID){
        this.spelerID = spelerID;
        addModel(model);
        addView(view);
    }

    private void addView(PlayerView view){
        this.view = view;
        this.view.addHandler(new ThrowDicesHandler());
        this.view.getStage().setTitle("Speler "+ spelerID);
        this.view.getStage().setX(this.view.getStage().getX()+(spelerID-1)*350);
    }

    private void addModel(Dobbelspel model){
        this.model = model;
        model.voegObserverToe(this);
        model.voegSpelerToe(spelerID);
    }

    @Override
    public void notify(Speler speler){
        if (speler.getId() == spelerID){
            view.getPlayButton().setDisable(false);
        }
    }

    @Override
    public void update(Speler speler) {
        view.getMessageLabel().setText(speler + " werpt " + speler.getVorigeWorpString()
                + " - score " + speler.getPunten() + " (+" + speler.getPuntenRonde() + ")");
    }

    @Override
    public void reset() {
        view.getMessageLabel().setText("Spel is nog niet gestart");
    }

    class ThrowDicesHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            model.speel();
            view.getPlayButton().setDisable(true);
        }
    }
}
