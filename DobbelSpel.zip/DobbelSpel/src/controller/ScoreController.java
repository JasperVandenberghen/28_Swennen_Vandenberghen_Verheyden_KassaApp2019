package controller;

import model.Dobbelspel;
import model.Observer;
import model.Speler;
import view.ScoreView;

public class ScoreController implements Observer {
    private ScoreView view;
    private Dobbelspel model;

    public ScoreController(ScoreView view, Dobbelspel model){
        addModel(model);
        addView(view);
    }

    private void addView(ScoreView view){
        this.view = view;
    }

    private void addModel(Dobbelspel model){
        this.model = model;
        model.voegObserverToe(this);
    }

    @Override
    public void notify(Speler speler) {

    }

    @Override
    public void update(Speler speler) {
        String string = "";
        if (model.getSpelerIndex() == 0){
            int beurt = model.totaalRondes - model.getAantalRondes() + 1;
            string = "\nBeurt " + beurt + ": ";
        }
        string += " sp" + speler.getId() + ": " + speler.getPunten();
        view.getScoreLabel().setText(view.getScoreLabel().getText() + string);
    }

    @Override
    public void reset() {
        view.getScoreLabel().setText("");
    }
}
