package model;

import controller.EindeSpelController;

import java.util.ArrayList;
import java.util.List;

public class Dobbelspel implements Observable{
    private List<Speler> spelers = new ArrayList<>();
    private List<Observer> observers = new ArrayList<>();
    private int aantalRondes,spelerIndex;
    public final static int totaalRondes = 3;

    public void voegSpelerToe(Speler speler){
        if (speler == null){
            throw new DomainException("Speler mag niet leeg zijn");
        }
        if (spelers.contains(speler)){
            throw new DomainException("Er is al een speler met id " + speler.getId());
        }
        this.spelers.add(speler);
    }

    public void voegSpelerToe(int spelerID){
        voegSpelerToe(new Speler(spelerID));
    }

    public void voegObserverToe(Observer observer){
        if (observer == null){
            throw new DomainException("Observer mag niet leeg zijn");
        }
        this.observers.add(observer);
    }

    private void checkIfSpelersEmpty(){
        if (spelers.size() == 0){
            throw new DomainException("Er zijn geen spelers");
        }
    }

    private Speler getSpelerAanBeurt(){
        return spelers.get(spelerIndex);
    }

    public int getAantalRondes(){
        return aantalRondes;
    }

    public int getSpelerIndex() {
        return spelerIndex;
    }

    public void speel(){
        Speler speler = getSpelerAanBeurt();
        int[] worp = speler.gooiDobbelsteen();
        int punten = berekenPunten(worp,speler.getVorigeWorp());
        speler.setPuntenRonde(punten);
        speler.voegPuntenToe(punten);
        speler.setVorigeWorp(worp);
        updateObservers(speler);
        spelerIndex++;
        if (isEindeRonde()){
            nieuweRonde();
        }
        else notifyObservers();
    }

    private boolean isEindeRonde(){
        return spelerIndex >= spelers.size();
    }

    private void nieuweRonde(){
        aantalRondes--;
        if (isEindeSpel()){
            eindeSpel();
        }
        else {
            spelerIndex = 0;
            notifyObservers();
        }
    }

    private boolean isEindeSpel(){
        return aantalRondes <= 0;
    }

    private void eindeSpel(){
        if (EindeSpelController.notify(this)){
            nieuwSpel();
        }
    }

    public void nieuwSpel(){
        resetObservers();
        resetScores();
        aantalRondes = totaalRondes;
        spelerIndex = 0;
        notifyObservers();
    }

    private void resetScores(){
        for (Speler speler : spelers){
            speler.setPunten(0);
        }
    }


    private int berekenPunten(int[] worp,int[] vorigeWorp){
        int punten = worp[0] + worp[1];
        if (worp[0] == worp[1]){
            punten *= 2;
        }
        if (worp[0] + worp[1] == vorigeWorp[0] + vorigeWorp[1]){
            punten += 5;
        }
        return punten;
    }

    public Speler getWinnaarSpel(){
        checkIfSpelersEmpty();
        Speler winnaarSpel = spelers.get(0);
        for (Speler speler : spelers){
            if (speler.getPunten() > winnaarSpel.getPunten()){
                winnaarSpel = speler;
            }
        }
        return winnaarSpel;
    }

    @Override
    public void notifyObservers(){
        for (Observer observer : observers){
            observer.notify(getSpelerAanBeurt());
        }
    }

    @Override
    public void updateObservers(Speler speler) {
        for (Observer observer : observers){
            observer.update(speler);
        }
    }

    @Override
    public void resetObservers() {
        for (Observer observer : observers){
            observer.reset();
        }
    }
}
