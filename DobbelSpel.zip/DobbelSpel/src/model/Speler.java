package model;

public class Speler {
    private int[] vorigeWorp = new int[2];
    private int punten,puntenRonde;
    private int id;

    public Speler(int id){
        this.id = id;
    }

    public int[] gooiDobbelsteen(){
        int[] worp = {Dobbelsteen.gooi(),Dobbelsteen.gooi()};
        return worp;
    }

    public void voegPuntenToe(int punten){
        this.punten += punten;
    }

    public void setPuntenRonde(int puntenRonde) {
        this.puntenRonde = puntenRonde;
    }

    public void setVorigeWorp(int[] vorigeWorp) {
        if (vorigeWorp.length == 0){
            throw new DomainException("array mag niet leeg zijn");
        }
        this.vorigeWorp = vorigeWorp;
    }

    public void setPunten(int punten){
        this.punten = punten;
    }

    public int getPunten() {
        return punten;
    }

    public int getPuntenRonde() {
        return puntenRonde;
    }

    public int[] getVorigeWorp() {
        return vorigeWorp;
    }

    public String getVorigeWorpString(){
        return vorigeWorp[0] + " en " + vorigeWorp[1];
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString(){
        return "Speler " + id;
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof Speler){
            return ((Speler) o).id == this.id;
        }
        return false;
    }
}
