package model;

public interface Observable {
    void updateObservers(Speler speler);
    void resetObservers();
    void notifyObservers();
}
