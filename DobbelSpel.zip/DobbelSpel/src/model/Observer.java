package model;

public interface Observer {
    void update(Speler speler);
    void reset();
    void notify(Speler speler);
}
