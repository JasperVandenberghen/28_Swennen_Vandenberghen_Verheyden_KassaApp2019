package model;

public class Dobbelsteen {

    public static int gooi(){
        return (int) Math.floor(Math.random()*6) + 1;
    }
}
