package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PlayerView {
	private Stage stage = new Stage();
	private Scene playerScene;
	private Label diceLabel;
	private Button playButton;
	private Label messageLabel;
	
	public PlayerView(){
		diceLabel = new Label();
		playButton = new Button("Werp dobbelstenen");
		playButton.setDisable(true);
		messageLabel = new Label("Spel is nog niet gestart");
		layoutComponents();
		stage.setScene(playerScene);
		stage.setResizable(false);
		stage.setX(100);
		stage.setY(200);
		stage.show();
	}

	private void layoutComponents() {
		VBox root = new VBox(10);
		playerScene = new Scene(root,250,100);
		root.getChildren().add(playButton);
		root.getChildren().add(diceLabel);
		root.getChildren().add(messageLabel);			
	}

	public Label getMessageLabel(){
		return messageLabel;
	}

	public Button getPlayButton() {
		return playButton;
	}

	public Stage getStage() {
		return stage;
	}

	public void addHandler(EventHandler<ActionEvent> handler){
		playButton.setOnAction(handler);
	}
}
