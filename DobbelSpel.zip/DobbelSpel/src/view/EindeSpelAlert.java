package view;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

public class EindeSpelAlert {

    public static boolean show(String speler){
        ButtonType button = new ButtonType("Opnieuw spelen", ButtonBar.ButtonData.OK_DONE);
        Alert alert = new Alert(Alert.AlertType.INFORMATION,"",button,ButtonType.CLOSE);
        alert.setTitle("Nieuw spel?");
        alert.setHeaderText(speler + " heeft gewonnen!");
        alert.showAndWait();
        return alert.getResult().equals(button);
    }
}
