package application;

import controller.PlayerController;
import controller.ScoreController;
import model.Dobbelspel;
import javafx.application.Application;
import javafx.stage.Stage;
import view.PlayerView;
import view.ScoreView;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		Dobbelspel model = new Dobbelspel();

		ScoreView scoreView = new ScoreView();
		ScoreController scoreController= new ScoreController(scoreView,model);

		PlayerView playerView1 = new PlayerView();
		PlayerController playerController1 = new PlayerController(playerView1,model,1);

		PlayerView playerView2 = new PlayerView();
		PlayerController playerController2 = new PlayerController(playerView2,model,2);

		PlayerView playerView3 = new PlayerView();
		PlayerController playerController3 = new PlayerController(playerView3,model,3);

		model.nieuwSpel();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
